Instructions to run : 

$ python3 instagram.py

-- It would take around "2.5 minutes" for the entire program to finish